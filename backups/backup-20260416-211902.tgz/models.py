import os
from datetime import datetime
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    create_engine,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from werkzeug.security import check_password_hash, generate_password_hash

from flask_login import UserMixin

from pathlib import Path

DB_PATH = Path("instance/db.sqlite3")
DB_PATH.parent.mkdir(exist_ok=True, parents=True)
DB_URL = f"sqlite:///{DB_PATH}"
engine = create_engine(DB_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

# === JETZT RICHTIG: UserMixin + Base ===
class User(UserMixin, Base):          # ← DAS WAR’S!!! DAS WAR DER LETZTE BUG!!!
    __tablename__ = "model_users"
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=True)
    # ... alles andere bleibt 100 % gleich ...

    # Subscription Info
    stripe_customer_id = Column(String(255), unique=True, nullable=True)
    stripe_subscription_id = Column(String(255), nullable=True)
    plan = Column(String(50), default="free")  # free, basic, pro, team
    plan_status = Column(String(50), default="active")  # active, canceled, past_due

    # Telegram
    telegram_chat_id = Column(String(255), nullable=True, unique=True)
    telegram_username = Column(String(255), nullable=True)
    telegram_verified = Column(Boolean, default=False)
    telegram_enabled = Column(
        Boolean, default=True
    )  # User kann Telegram Alerts aus/einschalten

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)

    # Relationships
    agents = relationship(
        "SearchAgent", back_populates="user", cascade="all, delete-orphan"
    )

    def set_password(self, password):
        """Hash und speichere Passwort"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Überprüfe Passwort"""
        return check_password_hash(self.password_hash, password)

    def get_alert_limit(self):
        """Gibt Limit basierend auf Plan zurück"""
        limits = {"free": 3, "basic": 10, "pro": 30, "team": 100}
        return limits.get(self.plan, 3)

    def can_create_agent(self):
        """Prüft ob User noch Agenten erstellen kann"""
        return len(self.agents) < self.get_alert_limit()

    def __repr__(self):
        return f"<User {self.email} ({self.plan})>"


    def is_active(self):
        return self.is_active  # oder einfach: return True

    def is_anonymous(self):
        return False

    def get_id(self):
        return str(self.id)

        def get_id(self):
            return str(self.id)

    def is_active(self):
        return self.is_active  # oder einfach: return True

    def is_anonymous(self):
        return False

    def is_authenticated(self):
        return True


class SearchAgent(Base):
    __tablename__ = "search_agents"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False)

    # NEU: Erweiterte Filter
    listing_type = Column(
        String(20), default="all"
    )  # all, auction, buy_it_now, auction_with_bin
    location_country = Column(String(10), default="DE")  # DE, AT, CH, etc.
    max_distance_km = Column(Integer, nullable=True)  # z.B. 50, 100, 200
    zip_code = Column(String(10), nullable=True)  # Für Umkreissuche

    free_shipping_only = Column(Boolean, default=False)
    returns_accepted = Column(Boolean, default=False)
    top_rated_seller_only = Column(Boolean, default=False)
    exclude_international = Column(Boolean, default=False)

    # Suchparameter
    name = Column(String(255), nullable=False)  # User-defined Name
    keywords = Column(Text, nullable=False)
    category = Column(String(100), nullable=True)
    min_price = Column(Integer, nullable=True)
    max_price = Column(Integer, nullable=True)
    condition = Column(String(50), nullable=True)  # new, used, etc.

    # Alert Settings
    check_interval = Column(Integer, default=60)  # Minuten
    notify_email = Column(Boolean, default=True)
    notify_telegram = Column(Boolean, default=True)

    # Status
    is_active = Column(Boolean, default=True)
    last_check = Column(DateTime, nullable=True)
    last_result_count = Column(Integer, default=0)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = relationship("User", back_populates="agents")
    results = relationship(
        "SearchResult", back_populates="agent", cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<SearchAgent '{self.name}' by User {self.user_id}>"


class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    keywords = Column(Text, nullable=False)
    category = Column(String(100), nullable=True)
    min_price = Column(Float, nullable=True)
    max_price = Column(Float, nullable=True)
    current_price = Column(Float, nullable=True)
    is_active = Column(Boolean, default=True)
    last_check = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user = relationship("User", backref="alerts")
    price_histories = relationship("PriceHistory", back_populates="alert", cascade="all, delete-orphan")
    price_forecasts = relationship("PriceForecast", back_populates="alert", cascade="all, delete-orphan")
    trend_analyses = relationship("PriceTrendAnalysis", back_populates="alert", cascade="all, delete-orphan")
    def __repr__(self):
        return f"<Alert {self.name} user={self.user_id}>"


class SearchResult(Base):
    __tablename__ = "search_results"

    id = Column(Integer, primary_key=True)
    agent_id = Column(Integer, ForeignKey("search_agents.id"), nullable=False)

    # eBay Item Info
    item_id = Column(String(255), unique=True, nullable=False, index=True)
    title = Column(Text, nullable=False)
    price = Column(String(50), nullable=True)
    currency = Column(String(10), default="EUR")
    url = Column(Text, nullable=False)
    image_url = Column(Text, nullable=True)
    condition = Column(String(50), nullable=True)
    location = Column(String(255), nullable=True)

    # Notification tracking
    notified_email = Column(Boolean, default=False)
    notified_telegram = Column(Boolean, default=False)

    # Metadata
    found_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    agent = relationship("SearchAgent", back_populates="results")

    def __repr__(self):
        return f"<SearchResult {self.item_id}: {self.title[:30]}>"


class WatchedItem(Base):
    __tablename__ = "watched_items"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False)

    # eBay Item Info
    ebay_item_id = Column(String(255), nullable=False, index=True)
    item_title = Column(Text, nullable=False)
    item_url = Column(Text, nullable=False)
    image_url = Column(Text, nullable=True)

    # Preis-Tracking
    initial_price = Column(String(50))
    current_price = Column(String(50))
    currency = Column(String(10), default="EUR")
    lowest_price = Column(String(50), nullable=True)

    # Notification Settings
    notify_price_drop = Column(Boolean, default=True)
    notify_auction_ending = Column(Boolean, default=True)
    price_drop_threshold = Column(Integer, default=5)  # % Preissenkung

    # Status
    is_active = Column(Boolean, default=True)
    item_status = Column(String(20), default="active")  # active, ended, unavailable

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    last_checked = Column(DateTime, default=datetime.utcnow)
    last_notified = Column(DateTime, nullable=True)

    # Relationship
    user = relationship("User", backref="watched_items")

    def __repr__(self):
        return f"<WatchedItem {self.ebay_item_id}: {self.item_title[:30]}>"


class PriceHistory(Base):
    __tablename__ = "price_history"

    id = Column(Integer, primary_key=True)
    alert_id = Column(Integer, ForeignKey("alerts.id"), nullable=True, index=True)

    # Suchbegriff
    search_term = Column(String(255), nullable=False, index=True)
    category = Column(String(100), nullable=True)

    # Preis-Statistiken
    avg_price = Column(Float, nullable=False)
    min_price = Column(Float, nullable=False)
    max_price = Column(Float, nullable=False)
    median_price = Column(Float, nullable=True)

    # Metadata
    item_count = Column(Integer, default=0)
    condition = Column(String(50), nullable=True)  # NEW, USED, etc.

    # Zeitstempel
    recorded_at = Column(DateTime, default=datetime.utcnow, index=True)

    alert = relationship("Alert", back_populates="price_histories")
    
    def __repr__(self):
        return f"<PriceHistory '{self.search_term}' @ {self.recorded_at.strftime('%Y-%m-%d')}>"


class ItemPriceTracking(Base):
    __tablename__ = "item_price_tracking"

    id = Column(Integer, primary_key=True)
    watched_item_id = Column(Integer, ForeignKey("watched_items.id"), nullable=False)

    price = Column(Float, nullable=False)
    currency = Column(String(10), default="EUR")

    # Status
    item_available = Column(Boolean, default=True)
    bid_count = Column(Integer, default=0)  # Bei Auktionen

    recorded_at = Column(DateTime, default=datetime.utcnow, index=True)

    # Relationship
    watched_item = relationship("WatchedItem", backref="price_snapshots")

    def __repr__(self):
        return f"<ItemPriceTracking {self.watched_item_id}: {self.price} @ {self.recorded_at}>"


# Erstelle alle Tabellen
def init_db():
    """Initialisiert die Datenbank"""
    Base.metadata.create_all(bind=engine)
    print("[OK] Datenbank-Tabellen erstellt!")


try:
    Base.metadata.create_all(bind=engine)
    print("[OK] models.py: Tabellen initialisiert")
except Exception as e:
    print(f"[models] Fehler beim Erstellen der Tabellen: {e}")



# Helper Functions
def get_db_session():
    """Gibt eine DB-Session zurück (für Flask Routes) - GENERATOR für use in with Statements"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_db():
    """Gibt eine neue SQLAlchemy Session direkt zurück (kein Generator)"""
    return SessionLocal()


    # In models.py - am Ende einfügen

class NotificationSettings(Base):
    __tablename__ = "notification_settings"

    user_id = Column(Integer, ForeignKey("model_users.id"), primary_key=True)

    # Zeitfenster (Ruhezeiten)
    quiet_hours_enabled = Column(Boolean, default=False)
    quiet_hours_start = Column(String(5), default="22:00")  # HH:MM
    quiet_hours_end = Column(String(5), default="08:00")

    # Frequenz-Limits
    max_notifications_per_day = Column(Integer, default=50)
    max_notifications_per_hour = Column(Integer, default=10)
    batch_notifications = Column(Boolean, default=False)  # Sammeln & 1x/Tag senden
    batch_time = Column(String(5), default="09:00")  # Wann Batch senden

    # Kanäle
    email_enabled = Column(Boolean, default=True)
    telegram_enabled = Column(Boolean, default=True)
    sms_enabled = Column(Boolean, default=False)  # Premium-Feature

    # Prioritäten
    only_high_priority = Column(Boolean, default=False)  # Nur wichtige Alerts
    min_price_drop_percent = Column(Integer, default=5)  # Min. X% Preissenkung

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationship
    user = relationship("User", backref="notification_settings")


class NotificationLog(Base):
    __tablename__ = "notification_log"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False)

    # Notification Details
    notification_type = Column(String(50), nullable=False)  # price_drop, new_item, auction_ending, etc.
    channel = Column(String(20), nullable=False)  # email, telegram, sms

    subject = Column(String(255))
    content = Column(Text)

    # Item Reference (optional)
    watched_item_id = Column(Integer, ForeignKey("watched_items.id"), nullable=True)
    agent_id = Column(Integer, ForeignKey("search_agents.id"), nullable=True)

    # Status
    status = Column(String(20), default="pending")  # pending, sent, failed, skipped
    sent_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    # Relationships
    user = relationship("User")
    watched_item = relationship("WatchedItem")
    agent = relationship("SearchAgent")


    # --- safe fallback / stub für sync_user_from_app ---
# Füge das am Ende von models.py ein, falls die Funktion fehlt.
from typing import Optional

def sync_user_from_app(session, app_user_id: Optional[int] = None, email: Optional[str] = None):
    """
    Minimaler Fallback: versucht, einen User anhand email/app_user_id zu finden.
    - session: entweder SessionLocal() Factory oder eine bereits geöffnete Session
    Gibt ein User-Objekt zurück oder ein Dummy-Objekt mit id/email Attributen.
    Passe die Implementierung an dein User-Model an.
    """
    created_session = False
    db = None
    try:
        # Wenn session eine Factory ist (SessionLocal), rufe sie auf
        if callable(session):
            db = session()
            created_session = True
        else:
            db = session
    except Exception:
        db = None

    try:
        if db is not None and email:
            # Versuche echten User aus DB zu holen — passe User-Attribute an
            try:
                user_obj = db.query(User).filter(User.email == email).first()
                if user_obj:
                    return user_obj
            except Exception:
                # falls ORM/Model anders ist, safe fallback
                pass

        # Wenn kein DB-User gefunden: gib ein einfaches Dummy-Objekt zurück
        TmpUser = type("TmpUser", (), {"id": app_user_id or None, "email": email})
        return TmpUser
    finally:
        if created_session and db is not None:
            try:
                db.close()
            except Exception:
                pass



class AffiliateAccount(Base):
    __tablename__ = "affiliate_accounts"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, unique=True)
    
    referral_code = Column(String(50), unique=True, nullable=False, index=True)
    referral_url = Column(Text, nullable=False)
    
    total_clicks = Column(Integer, default=0)
    total_conversions = Column(Integer, default=0)
    total_earnings = Column(Float, default=0.0)
    
    commission_rate = Column(Float, default=0.15)
    
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", backref="affiliate_account")
    referral_clicks = relationship("AffiliateClick", back_populates="affiliate", cascade="all, delete-orphan")
    referral_conversions = relationship("AffiliateConversion", back_populates="affiliate", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<AffiliateAccount {self.referral_code}>"


class AffiliateClick(Base):
    __tablename__ = "affiliate_clicks"

    id = Column(Integer, primary_key=True)
    affiliate_id = Column(Integer, ForeignKey("affiliate_accounts.id"), nullable=False)
    
    referrer_ip = Column(String(50), nullable=True)
    referrer_url = Column(Text, nullable=True)
    user_agent = Column(Text, nullable=True)
    
    converted = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    affiliate = relationship("AffiliateAccount", back_populates="referral_clicks")

    def __repr__(self):
        return f"<AffiliateClick {self.affiliate_id} @ {self.created_at}>"


class AffiliateConversion(Base):
    __tablename__ = "affiliate_conversions"

    id = Column(Integer, primary_key=True)
    affiliate_id = Column(Integer, ForeignKey("affiliate_accounts.id"), nullable=False)
    click_id = Column(Integer, ForeignKey("affiliate_clicks.id"), nullable=True)
    
    converted_user_id = Column(Integer, ForeignKey("model_users.id"), nullable=True)
    
    conversion_type = Column(String(50), default="signup")
    commission_amount = Column(Float, default=0.0)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    affiliate = relationship("AffiliateAccount", back_populates="referral_conversions")
    click = relationship("AffiliateClick")
    converted_user = relationship("User")

    def __repr__(self):
        return f"<AffiliateConversion {self.affiliate_id}>"


class CommunityLink(Base):
    __tablename__ = "community_links"

    id = Column(Integer, primary_key=True)
    
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    url = Column(Text, nullable=False)
    
    category = Column(String(50), nullable=False)
    icon = Column(String(50), nullable=True)
    
    is_featured = Column(Boolean, default=False)
    display_order = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<CommunityLink '{self.title}'>"


class NewsletterSubscriber(Base):
    __tablename__ = "newsletter_subscribers"

    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    verified = Column(Boolean, default=False)
    verification_token = Column(String(255), nullable=True, unique=True)
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    verified_at = Column(DateTime, nullable=True)
    unsubscribed_at = Column(DateTime, nullable=True)

    def __repr__(self):
        return f"<NewsletterSubscriber {self.email}>"


class Coupon(Base):
    __tablename__ = "coupons"

    id = Column(Integer, primary_key=True)
    
    code = Column(String(50), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)
    
    amount = Column(Float, nullable=False)
    discount_type = Column(String(20), default="fixed")
    
    is_affiliate = Column(Boolean, default=False)
    affiliate_conversion_id = Column(Integer, ForeignKey("affiliate_conversions.id"), nullable=True)
    
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=True)
    
    usage_limit = Column(Integer, nullable=True)
    used_count = Column(Integer, default=0)
    
    valid_from = Column(DateTime, default=datetime.utcnow)
    valid_until = Column(DateTime, nullable=True)
    
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", backref="coupons")
    affiliate_conversion = relationship("AffiliateConversion")
    usages = relationship("CouponUsage", back_populates="coupon", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Coupon {self.code}>"
    
    def is_valid(self):
        """Check if coupon is still valid and can be used"""
        now = datetime.utcnow()
        if not self.is_active:
            return False
        if self.valid_until and now > self.valid_until:
            return False
        if self.valid_from and now < self.valid_from:
            return False
        if self.usage_limit and self.used_count >= self.usage_limit:
            return False
        return True


class CouponUsage(Base):
    __tablename__ = "coupon_usages"

    id = Column(Integer, primary_key=True)
    coupon_id = Column(Integer, ForeignKey("coupons.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False)
    
    applied_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    coupon = relationship("Coupon", back_populates="usages")
    user = relationship("User", backref="coupon_usages")

    def __repr__(self):
        return f"<CouponUsage {self.coupon_id} by User {self.user_id}>"


class AnalyticsSnapshot(Base):
    __tablename__ = "analytics_snapshots"

    id = Column(Integer, primary_key=True)
    
    snapshot_date = Column(DateTime, default=datetime.utcnow, index=True)
    
    total_users = Column(Integer, default=0)
    total_premium_users = Column(Integer, default=0)
    total_basic_users = Column(Integer, default=0)
    total_pro_users = Column(Integer, default=0)
    total_team_users = Column(Integer, default=0)
    
    new_signups = Column(Integer, default=0)
    churned_users = Column(Integer, default=0)
    
    affiliate_clicks = Column(Integer, default=0)
    affiliate_conversions = Column(Integer, default=0)
    affiliate_earnings = Column(Float, default=0.0)
    
    coupons_created = Column(Integer, default=0)
    coupons_redeemed = Column(Integer, default=0)
    coupons_total_value = Column(Float, default=0.0)
    
    agents_created = Column(Integer, default=0)
    agents_active = Column(Integer, default=0)
    alerts_triggered = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<AnalyticsSnapshot {self.snapshot_date.strftime('%Y-%m-%d')}>"


class AnalyticsEvent(Base):
    __tablename__ = "analytics_events"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=True)
    
    event_type = Column(String(50), nullable=False, index=True)
    event_name = Column(String(255), nullable=False)
    
    event_data = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    user = relationship("User", backref="analytics_events")

    def __repr__(self):
        return f"<AnalyticsEvent {self.event_type}:{self.event_name}>"


class Achievement(Base):
    __tablename__ = "achievements"

    id = Column(Integer, primary_key=True)
    
    code = Column(String(50), unique=True, nullable=False, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    icon = Column(String(100), nullable=True)
    
    category = Column(String(50), nullable=False)
    points = Column(Integer, default=10)
    
    trigger_type = Column(String(50), nullable=False)
    trigger_condition = Column(String(255), nullable=False)
    
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user_badges = relationship("UserBadge", back_populates="achievement", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Achievement {self.code}>"


class UserBadge(Base):
    __tablename__ = "user_badges"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    achievement_id = Column(Integer, ForeignKey("achievements.id"), nullable=False)
    
    earned_at = Column(DateTime, default=datetime.utcnow, index=True)
    is_public = Column(Boolean, default=True)
    
    achievement = relationship("Achievement", back_populates="user_badges")
    user = relationship("User", backref="badges")

    def __repr__(self):
        return f"<UserBadge user={self.user_id} achievement={self.achievement_id}>"


class UserEngagement(Base):
    __tablename__ = "user_engagement"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, unique=True)
    
    login_streak = Column(Integer, default=0)
    last_login = Column(DateTime, nullable=True)
    
    searches_count = Column(Integer, default=0)
    agents_created = Column(Integer, default=0)
    alerts_triggered = Column(Integer, default=0)
    
    affiliate_clicks = Column(Integer, default=0)
    affiliate_conversions = Column(Integer, default=0)
    
    coupons_applied = Column(Integer, default=0)
    coupons_created = Column(Integer, default=0)
    
    total_points = Column(Integer, default=0)
    tier = Column(String(50), default="bronze")
    
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", backref="engagement", uselist=False)

    def __repr__(self):
        return f"<UserEngagement user={self.user_id} tier={self.tier}>"


class LeaderboardSnapshot(Base):
    __tablename__ = "leaderboard_snapshots"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False)
    
    period = Column(String(20), nullable=False)
    rank = Column(Integer, nullable=True)
    points = Column(Integer, default=0)
    metric_value = Column(Integer, default=0)
    metric_type = Column(String(50), nullable=False)
    
    snapshot_date = Column(DateTime, default=datetime.utcnow, index=True)
    
    user = relationship("User", backref="leaderboard_snapshots")

    def __repr__(self):
        return f"<LeaderboardSnapshot user={self.user_id} period={self.period}>"


class WebhookEndpoint(Base):
    __tablename__ = "webhook_endpoints"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    name = Column(String(255), nullable=False)
    url = Column(String(500), nullable=False)
    secret = Column(String(255), nullable=False, unique=True)
    
    events = Column(String(500), nullable=False)
    
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    
    retry_count = Column(Integer, default=3)
    timeout = Column(Integer, default=5)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    last_triggered = Column(DateTime, nullable=True)
    
    webhook_logs = relationship("WebhookLog", back_populates="endpoint", cascade="all, delete-orphan")
    user = relationship("User", backref="webhooks")

    def __repr__(self):
        return f"<WebhookEndpoint {self.name} ({self.url})>"


class WebhookEvent(Base):
    __tablename__ = "webhook_events"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    event_type = Column(String(100), nullable=False, index=True)
    event_data = Column(Text, nullable=False)
    
    source = Column(String(50), nullable=False)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    webhook_logs = relationship("WebhookLog", back_populates="event")
    user = relationship("User", backref="webhook_events")

    def __repr__(self):
        return f"<WebhookEvent {self.event_type} user={self.user_id}>"


class WebhookLog(Base):
    __tablename__ = "webhook_logs"

    id = Column(Integer, primary_key=True)
    endpoint_id = Column(Integer, ForeignKey("webhook_endpoints.id"), nullable=False, index=True)
    event_id = Column(Integer, ForeignKey("webhook_events.id"), nullable=False, index=True)
    
    status = Column(String(50), nullable=False)
    response_code = Column(Integer, nullable=True)
    response_body = Column(Text, nullable=True)
    error_message = Column(Text, nullable=True)
    
    attempt_number = Column(Integer, default=1)
    next_retry_at = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    completed_at = Column(DateTime, nullable=True)
    
    endpoint = relationship("WebhookEndpoint", back_populates="webhook_logs")
    event = relationship("WebhookEvent", back_populates="webhook_logs")

    def __repr__(self):
        return f"<WebhookLog endpoint={self.endpoint_id} status={self.status}>"


class SMSNotificationSetting(Base):
    __tablename__ = "sms_notification_settings"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, unique=True, index=True)
    
    phone_number = Column(String(20), nullable=True)
    phone_verified = Column(Boolean, default=False)
    verification_code = Column(String(6), nullable=True)
    verification_attempts = Column(Integer, default=0)
    
    is_enabled = Column(Boolean, default=False)
    alert_types = Column(String(500), default="price_drop,new_item")
    
    max_sms_per_day = Column(Integer, default=5)
    quiet_hours_start = Column(String(5), default="22:00")
    quiet_hours_end = Column(String(5), default="08:00")
    
    total_sms_sent = Column(Integer, default=0)
    total_sms_cost = Column(Float, default=0.0)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", backref="sms_settings", uselist=False)
    sms_logs = relationship("SMSSendLog", back_populates="settings", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<SMSNotificationSetting user={self.user_id} phone={self.phone_number}>"


class SMSSendLog(Base):
    __tablename__ = "sms_send_logs"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    settings_id = Column(Integer, ForeignKey("sms_notification_settings.id"), nullable=True)
    
    phone_number = Column(String(20), nullable=False)
    message_content = Column(Text, nullable=False)
    alert_type = Column(String(100), nullable=True)
    
    status = Column(String(50), default="pending")
    provider_message_id = Column(String(255), nullable=True)
    error_message = Column(Text, nullable=True)
    
    cost_cents = Column(Integer, default=0)
    retry_count = Column(Integer, default=0)
    
    sent_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    user = relationship("User", backref="sms_logs")
    settings = relationship("SMSNotificationSetting", back_populates="sms_logs")

    def __repr__(self):
        return f"<SMSSendLog user={self.user_id} status={self.status}>"


class APIKey(Base):
    __tablename__ = "api_keys"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    name = Column(String(255), nullable=False)
    key = Column(String(255), unique=True, nullable=False, index=True)
    secret = Column(String(255), nullable=False)
    
    permissions = Column(String(500), default="read,write")
    
    is_active = Column(Boolean, default=True)
    last_used = Column(DateTime, nullable=True)
    last_ip = Column(String(45), nullable=True)
    
    rate_limit = Column(Integer, default=1000)
    rate_limit_window = Column(Integer, default=3600)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)
    
    user = relationship("User", backref="api_keys")

    def __repr__(self):
        return f"<APIKey {self.name}>"


class APIKeyLog(Base):
    __tablename__ = "api_key_logs"

    id = Column(Integer, primary_key=True)
    api_key_id = Column(Integer, ForeignKey("api_keys.id"), nullable=False, index=True)
    
    method = Column(String(10), nullable=False)
    endpoint = Column(String(255), nullable=False)
    status_code = Column(Integer, nullable=False)
    response_time = Column(Float, default=0.0)
    
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(String(500), nullable=True)
    
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    api_key = relationship("APIKey", backref="logs")

    def __repr__(self):
        return f"<APIKeyLog {self.method} {self.endpoint} {self.status_code}>"


class Report(Base):
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    report_type = Column(String(50), nullable=False)
    format = Column(String(20), default="pdf")
    
    is_scheduled = Column(Boolean, default=False)
    schedule_frequency = Column(String(20), nullable=True)
    schedule_day_of_month = Column(Integer, nullable=True)
    schedule_day_of_week = Column(Integer, nullable=True)
    schedule_time = Column(String(5), nullable=True)
    
    email_recipients = Column(Text, nullable=True)
    include_charts = Column(Boolean, default=True)
    include_summary = Column(Boolean, default=True)
    include_detailed_data = Column(Boolean, default=True)
    
    filters = Column(Text, nullable=True)
    
    is_enabled = Column(Boolean, default=True)
    last_generated = Column(DateTime, nullable=True)
    next_scheduled = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", backref="reports")
    generations = relationship("ReportGeneration", back_populates="report", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Report {self.name} user={self.user_id}>"


class ReportGeneration(Base):
    __tablename__ = "report_generations"

    id = Column(Integer, primary_key=True)
    report_id = Column(Integer, ForeignKey("reports.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    status = Column(String(50), default="pending")
    file_path = Column(String(500), nullable=True)
    file_size = Column(Integer, nullable=True)
    file_url = Column(String(500), nullable=True)
    
    error_message = Column(Text, nullable=True)
    
    generation_time_ms = Column(Integer, nullable=True)
    row_count = Column(Integer, default=0)
    
    triggered_by = Column(String(50), default="manual")
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    completed_at = Column(DateTime, nullable=True)
    expires_at = Column(DateTime, nullable=True)
    
    report = relationship("Report", back_populates="generations")
    user = relationship("User", backref="report_generations")

    def __repr__(self):
        return f"<ReportGeneration report={self.report_id} status={self.status}>"


class ReportTemplate(Base):
    __tablename__ = "report_templates"

    id = Column(Integer, primary_key=True)
    
    name = Column(String(255), nullable=False, unique=True)
    description = Column(Text, nullable=True)
    report_type = Column(String(50), nullable=False)
    
    format = Column(String(20), default="pdf")
    include_charts = Column(Boolean, default=True)
    include_summary = Column(Boolean, default=True)
    include_detailed_data = Column(Boolean, default=True)
    
    default_filters = Column(Text, nullable=True)
    
    is_premium = Column(Boolean, default=False)
    min_plan = Column(String(50), default="basic")
    
    icon = Column(String(50), nullable=True)
    color = Column(String(7), nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<ReportTemplate {self.name}>"


class UserRole(Base):
    __tablename__ = "user_roles"

    id = Column(Integer, primary_key=True)
    
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text, nullable=True)
    
    permissions = Column(Text, nullable=True)
    
    is_system_role = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user_role_assignments = relationship("UserRoleAssignment", back_populates="role", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<UserRole {self.name}>"


class UserRoleAssignment(Base):
    __tablename__ = "user_role_assignments"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    role_id = Column(Integer, ForeignKey("user_roles.id"), nullable=False, index=True)
    
    assigned_by = Column(Integer, ForeignKey("model_users.id"), nullable=True)
    assigned_at = Column(DateTime, default=datetime.utcnow)
    
    expires_at = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    
    user = relationship("User", foreign_keys=[user_id], backref="role_assignments")
    role = relationship("UserRole", back_populates="user_role_assignments")
    assigned_by_user = relationship("User", foreign_keys=[assigned_by])

    def __repr__(self):
        return f"<UserRoleAssignment user={self.user_id} role={self.role_id}>"


class SponsorLevel(Base):
    __tablename__ = "sponsor_levels"

    id = Column(Integer, primary_key=True)
    
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text, nullable=True)
    
    monthly_price = Column(Float, nullable=False)
    
    benefits = Column(Text, nullable=True)
    max_team_members = Column(Integer, default=1)
    
    badge_color = Column(String(7), nullable=True)
    badge_icon = Column(String(50), nullable=True)
    
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    sponsors = relationship("Sponsor", back_populates="level", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<SponsorLevel {self.name}>"


class Sponsor(Base):
    __tablename__ = "sponsors"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True, unique=True)
    
    level_id = Column(Integer, ForeignKey("sponsor_levels.id"), nullable=False)
    
    monthly_donation = Column(Float, default=0.0)
    total_donated = Column(Float, default=0.0)
    
    started_at = Column(DateTime, default=datetime.utcnow)
    canceled_at = Column(DateTime, nullable=True)
    
    stripe_subscription_id = Column(String(255), nullable=True)
    
    is_active = Column(Boolean, default=True)
    auto_renew = Column(Boolean, default=True)
    
    custom_badge_name = Column(String(100), nullable=True)
    custom_badge_color = Column(String(7), nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", backref="sponsor_profile", uselist=False)
    level = relationship("SponsorLevel", back_populates="sponsors")

    def __repr__(self):
        return f"<Sponsor user={self.user_id} level={self.level_id}>"


class TeamMember(Base):
    __tablename__ = "team_members"

    id = Column(Integer, primary_key=True)
    
    owner_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    member_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    role = Column(String(50), default="member")
    permissions = Column(Text, nullable=True)
    
    invited_at = Column(DateTime, default=datetime.utcnow)
    joined_at = Column(DateTime, nullable=True)
    
    is_active = Column(Boolean, default=True)
    can_manage_alerts = Column(Boolean, default=True)
    can_manage_team = Column(Boolean, default=False)
    can_view_reports = Column(Boolean, default=True)
    
    owner = relationship("User", foreign_keys=[owner_id], backref="owned_teams")
    member = relationship("User", foreign_keys=[member_id], backref="team_memberships")

    def __repr__(self):
        return f"<TeamMember owner={self.owner_id} member={self.member_id}>"


class WhiteLabelBrand(Base):
    __tablename__ = "white_label_brands"

    id = Column(Integer, primary_key=True)
    reseller_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True, unique=True)
    
    brand_name = Column(String(255), nullable=False)
    brand_domain = Column(String(255), nullable=True, unique=True)
    brand_logo_url = Column(String(500), nullable=True)
    brand_favicon_url = Column(String(500), nullable=True)
    
    primary_color = Column(String(7), default="#3b82f6")
    secondary_color = Column(String(7), default="#2563eb")
    accent_color = Column(String(7), default="#10b981")
    
    support_email = Column(String(255), nullable=True)
    support_phone = Column(String(20), nullable=True)
    support_url = Column(String(500), nullable=True)
    
    custom_css = Column(Text, nullable=True)
    footer_text = Column(String(500), nullable=True)
    
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    reseller = relationship("User", backref="white_label_brand", uselist=False)

    def __repr__(self):
        return f"<WhiteLabelBrand {self.brand_name}>"


class ResellerAccount(Base):
    __tablename__ = "reseller_accounts"

    id = Column(Integer, primary_key=True)
    reseller_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True, unique=True)
    
    company_name = Column(String(255), nullable=False)
    company_address = Column(Text, nullable=True)
    company_tax_id = Column(String(50), nullable=True)
    
    reseller_discount_percentage = Column(Float, default=20.0)
    
    max_end_users = Column(Integer, default=100)
    current_end_users = Column(Integer, default=0)
    
    commission_percentage = Column(Float, default=15.0)
    total_revenue = Column(Float, default=0.0)
    total_commission = Column(Float, default=0.0)
    
    api_key = Column(String(255), nullable=True, unique=True)
    webhook_url = Column(String(500), nullable=True)
    
    is_approved = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    
    approved_at = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    reseller = relationship("User", backref="reseller_account", uselist=False)
    end_users = relationship("EndUserAccount", back_populates="reseller", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<ResellerAccount {self.company_name}>"


class EndUserAccount(Base):
    __tablename__ = "end_user_accounts"

    id = Column(Integer, primary_key=True)
    reseller_id = Column(Integer, ForeignKey("reseller_accounts.id"), nullable=False, index=True)
    end_user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    custom_domain = Column(String(255), nullable=True)
    
    plan = Column(String(50), default="basic")
    monthly_fee = Column(Float, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    reseller = relationship("ResellerAccount", back_populates="end_users")
    end_user = relationship("User", backref="reseller_end_user_account")

    def __repr__(self):
        return f"<EndUserAccount end_user={self.end_user_id}>"


class ResellerCommission(Base):
    __tablename__ = "reseller_commissions"

    id = Column(Integer, primary_key=True)
    reseller_id = Column(Integer, ForeignKey("reseller_accounts.id"), nullable=False, index=True)
    
    period = Column(String(20), nullable=False)
    
    total_revenue = Column(Float, default=0.0)
    commission_amount = Column(Float, default=0.0)
    commission_percentage = Column(Float, nullable=True)
    
    status = Column(String(50), default="pending")
    paid_at = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<ResellerCommission reseller={self.reseller_id} period={self.period}>"


class PriceForecast(Base):
    __tablename__ = "price_forecasts"

    id = Column(Integer, primary_key=True)
    alert_id = Column(Integer, ForeignKey("alerts.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    forecast_type = Column(String(50), nullable=False)
    
    current_price = Column(Float, nullable=True)
    
    predicted_price_7d = Column(Float, nullable=True)
    predicted_price_14d = Column(Float, nullable=True)
    predicted_price_30d = Column(Float, nullable=True)
    
    confidence_score_7d = Column(Float, nullable=True)
    confidence_score_14d = Column(Float, nullable=True)
    confidence_score_30d = Column(Float, nullable=True)
    
    trend_direction = Column(String(50), nullable=True)
    trend_strength = Column(Float, nullable=True)
    
    recommendation = Column(String(255), nullable=True)
    
    last_trained = Column(DateTime, nullable=True)
    training_samples = Column(Integer, default=0)
    model_accuracy = Column(Float, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    alert = relationship("Alert", back_populates="price_forecasts")
    user = relationship("User", backref="price_forecasts")

    def __repr__(self):
        return f"<PriceForecast alert={self.alert_id}>"


class PriceTrendAnalysis(Base):
    __tablename__ = "price_trend_analysis"

    id = Column(Integer, primary_key=True)
    alert_id = Column(Integer, ForeignKey("alerts.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    period_days = Column(Integer, default=30)
    
    min_price = Column(Float, nullable=True)
    max_price = Column(Float, nullable=True)
    avg_price = Column(Float, nullable=True)
    
    price_volatility = Column(Float, nullable=True)
    trend_slope = Column(Float, nullable=True)
    
    seasonal_pattern = Column(String(100), nullable=True)
    anomalies = Column(Text, nullable=True)
    
    price_drops_count = Column(Integer, default=0)
    avg_drop_percentage = Column(Float, nullable=True)
    
    best_buy_price = Column(Float, nullable=True)
    good_deal_threshold = Column(Float, nullable=True)
    fair_price_range_min = Column(Float, nullable=True)
    fair_price_range_max = Column(Float, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    alert = relationship("Alert", back_populates="trend_analyses")
    user = relationship("User", backref="trend_analyses")

    def __repr__(self):
        return f"<PriceTrendAnalysis alert={self.alert_id} period={self.period_days}d>"


class MarketInsight(Base):
    __tablename__ = "market_insights"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("model_users.id"), nullable=False, index=True)
    
    category = Column(String(255), nullable=False)
    
    market_trend = Column(String(50), nullable=True)
    average_price = Column(Float, nullable=True)
    price_range_min = Column(Float, nullable=True)
    price_range_max = Column(Float, nullable=True)
    
    demand_level = Column(String(50), nullable=True)
    supply_level = Column(String(50), nullable=True)
    
    competitive_intensity = Column(String(50), nullable=True)
    
    opportunities = Column(Text, nullable=True)
    risks = Column(Text, nullable=True)
    
    insights_count = Column(Integer, default=0)
    generated_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", backref="market_insights")

    def __repr__(self):
        return f"<MarketInsight user={self.user_id} category={self.category}>"


class MLModel(Base):
    __tablename__ = "ml_models"

    id = Column(Integer, primary_key=True)
    
    model_type = Column(String(100), nullable=False)
    model_name = Column(String(255), nullable=False)
    
    version = Column(String(50), default="1.0")
    
    accuracy = Column(Float, nullable=True)
    precision = Column(Float, nullable=True)
    recall = Column(Float, nullable=True)
    f1_score = Column(Float, nullable=True)
    
    training_date = Column(DateTime, nullable=True)
    training_samples = Column(Integer, default=0)
    
    parameters = Column(Text, nullable=True)
    
    is_active = Column(Boolean, default=True)
    last_updated = Column(DateTime, default=datetime.utcnow)
    
    created_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<MLModel {self.model_name}>"


if __name__ == "__main__":
    # Wenn direkt ausgeführt: Tabellen erstellen
    init_db()
